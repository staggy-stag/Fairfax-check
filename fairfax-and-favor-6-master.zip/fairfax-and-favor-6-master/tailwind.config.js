module.exports = {
  content: ["./**/*.{liquid,js,json}"],
  safelist: [
    'cta-2', 'pb-8', 'order-1', 'order-2', 'order-3', 'order-4', 'font-sans', 'md:grid-cols-4', 'rotate-180',
    '-bottom-16', '-top-16', 'mr-auto', 'ml-auto', 'min-h-[60vh]', 'min-w-sm', 'shrink', 'px-24', 'pb-16', 'pb-[79.6%]',
    'indent-0', 'indent-0.5', 'indent-1', 'indent-1.5', 'indent-2.5', 'text-[15px]', 'font-light', 'ordinal', 'text-opacity-50',
    'text-white/50', 'blur-none', 'grayscale', 'backdrop-filter', 'tracking-x-wide', 'md:text-2xl', 'lg:p-8',
    'headline-1-light', 'headline-2-light', 'headline-6-light', 'scale-200', 'z-11', 'z-12', 'leading-none', 'tracking-x-wide', 'bg-opacity-50', 'space-x-3', 'md:space-x-3',
    'order-1', 'order-2', 'order-3', 'order-4', 'order-5', 'order-6', 'order-7', 'order-8'
  ],
  theme: {
    fontFamily: {
      'sans': ['gill-sans-nova', 'sans-serif'],
      'serif': ['adobe-garamond-pro', 'serif'],
      'garamond-light': ['garamond-premier-pro-display', 'serif'],
    },
    extend: {
      colors: {
        'sg-off-black': '#161616',
        'sg-gold': '#AE8A6B',
        'sg-navy': '#1E293A',
        'sg-red': '#a73333',
        'sg-grey': '#DDD',
        'sg-grey-1': '#F0F0F0',
        'sg-grey-2': '#ebebeb',
        'sg-grey-3': '#d8d8d8',
        'sg-grey-4': '#c8c8c8',
        'sg-grey-5': '#8A8989',
        'sg-grey-6': '#636363',
        'sg-grey-7': '#555',
        'sg-ref': '#525843',
        'sg-val': '#990c39',
      },
      screens: {
        '3xl': '1800px',
      },
    },
  },
  plugins: [],
  corePlugins: {
   container: false,
  },
}