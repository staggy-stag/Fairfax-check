# Theme links

## Live

https://www.fairfaxandfavor.com/?preview_theme_id=120745295944

## Staging

https://www.fairfaxandfavor.com/?preview_theme_id=120848482376
https://www.fairfaxandfavor.com/products/the-regina-black-narrow-fit-suede-boot?preview_theme_id=120848482376

# Multi variant

- On variant click, dispatch "variant-change", set addToCart variantId and available
- AddToCart starts with a blank variantId, and when set button changes to add to cart, back in stock, or sold out message
- back-in-stock snippet shows based on variant being picked, !available and canSignup
- backInStock() listens for "variant-change", as it needs a variantId to signup for
- gift message side panel listens for "variant-change" for add with gift wrap
- canSignup has no logic at the moment, just permanently true
- Sticky add to bag listens for "variant-change" so it can match the selection

# Scenarios

## Fully stocked

- No extra considerations

## Partially stocked

- Click variant, if stocked, dispatch available = true, which means BiS won't show, add to bag will
- Click variant, if not stocked, dispatch available = false, BiS will show
- If the product has "no-restock" and isn't available, BiS snippet intercepts and shows a sold out message (provided there is an attached breadcrumb for it to show alternatives)
- "no-restock" currently hides a product on collections, so if you want to hide BiS and show on collection, this is currently not possible
- Discounted or tagged "discontinued" currently counts as a BiS exception, which makes a variant unclickable and adds text SOLD OUT

So current scenarios are:

1. Click stocked variant, add to bag shows
2. Click unstocked variant (undiscounted, not tagged "no-restock" / "discontinued"), back in stock shows
3. Unstocked + ("discontinued" OR discounted) - variant not clickable, worded SOLD OUT
4. Unstocked + "no-restock" - clickable, but sold out message might show (depending on breadcrumb), BiS won't show
5. Unstocked + tagged "BCN" - clickable, but sold out message might show (depending on breadcrumb), BiS won't show

discontinued

- When OOS, hides swatch on product cards, and hides alternative products showing from tabs (other styles etc)
- Makes variants show SOLD OUT (and unclickable)
- Label "SOLD OUT" for PLP when OOS

no-restock

- When OOS, hides swatch on product cards, and hides alternative products showing from tabs (other styles etc)
- Hides products from PLP when sold out
- Variants are clickable, but BiS won't show (a sold out message will show)

# TODO

- Make SOLD OUT clickable when partially stocked + no bis, revealing sold out messaging
- Fully sold out, don't show variants
- If discounted, show variants + sold out button