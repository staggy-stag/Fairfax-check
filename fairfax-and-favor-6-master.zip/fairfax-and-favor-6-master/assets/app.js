/**
 * Dekstop menu
 * - Add grace period for mouseouts
 */

 let state = document.querySelector('.js-state');
 let menuActive = false;
 let closeMenuTimeout = null;
 let changeMenuTimeout = null;
 let nextMenu = null;
 let currentActiveMenu = null;

 let womens_size_map = {
  'UK 2 EU 35': 'US 4',
  'UK 3 EU 36': 'US 5',
  'UK 4 EU 37': 'US 6',
  'UK 5 EU 38': 'US 7',
  'UK 6 EU 39': 'US 8',
  'UK 7 EU 40': 'US 9',
  'UK 7.5 EU 41': 'US 9.5',
  'UK 8 EU 42': 'US 10',
  'UK 9 EU 43': 'US 11',
  'UK 10 EU 44': 'US 12',
  'UK 3 - 6' : 'US 5 - 8',
  'UK 7 - 9' : 'US 9 - 11',
  'UK 8 EU 36' : 'US 4',
  'UK 10 EU 38' : 'US 6',
  'UK 12 EU 40' : 'US 8',
  'UK 14 EU 42' : 'US 10',
  'UK 16 EU 44' : 'US 12',
  'UK 18 EU 46' : 'US 14',
  'UK 6' : 'US 2',
  'UK 8' : 'US 4',
  'UK 10' : 'US 6',
  'UK 12' : 'US 7',
  'UK 14' : 'US 10',
  'UK 16' : 'US 12',
  'UK 18' : 'US 14',
};

let mens_size_map = {
  'UK 6 EU 40': 'US 7',
  'UK 7 EU 41': 'US 8',
  'UK 8 EU 42': 'US 9',
  'UK 9 EU 43': 'US 10',
  'UK 10 EU 44': 'US 11',
  'UK 11 EU 45': 'US 12',
  'UK 12 EU 46': 'US 13',
  'UK 13 EU 47': 'US 14',
  'UK 14 EU 48': 'US 15',
};

document.addEventListener('keydown', function(e) {
  if(e.key == 'Tab') {
    document.querySelector('body').classList.remove('no-outlines');
  }
});

document.querySelectorAll('.js-group').forEach(item => {
  item.addEventListener('mouseover', event => {

    let target = findParent(event, '.js-group');

    clearTimeout(closeMenuTimeout);
    clearTimeout(changeMenuTimeout);

    // If we have an active menu, allow a grace period in case mouse grazes over it when intent is to get mouse into submenu
    if(menuActive) {
      nextMenu = item;
      changeMenuTimeout = setTimeout(() => {
        // set classes to activate menu
        if(currentActiveMenu != target) {
          currentActiveMenu.querySelector('.js-submenu').classList.add('hidden');
          target.querySelector('.js-submenu').classList.remove('hidden');
          currentActiveMenu = target;
        }
      }, 150);
    } else {
      // New mouseover, so open straight away
      target.querySelector('.js-submenu').classList.remove('hidden');
      menuActive = true;
      currentActiveMenu = target;
    }

    // Set siblings so we can grey them out
    document.querySelectorAll('.js-desktop-nav-heading').forEach(item => {
        item.classList.add('opacity-50');
    });

    target.querySelector('.js-desktop-nav-heading').classList.remove('opacity-50');
  })

  // Add a grace period for exiting menu. Has to be longer than the switch menu
  item.addEventListener('mouseout', event => {
    closeMenuTimeout = setTimeout(() => {
      menuActive = false;
      if(currentActiveMenu) {
        currentActiveMenu.querySelector('.js-submenu').classList.add('hidden');
      }
      document.querySelectorAll('.js-desktop-nav-heading').forEach(item => {
        item.classList.remove('opacity-50');
    });
    }, 300);
  });

  // Keyboard accessbility
  item.querySelector('a').addEventListener("click",  function(event){

    let menu = findParent(event, '.js-group');
    let submenu = menu.querySelector('.js-submenu');
    submenu.classList.toggle('hidden');

    // Set all other menus to hidden
    document.querySelectorAll('.js-submenu').forEach(item => {
      if(item != submenu) {
        item.classList.add('hidden');
      }
    });

    event.preventDefault();
	});
});

function findParent(event, parentClass) {
  let target = null;

  // Get the js-group item by traversing through parents (the event target will be the child mouseover html element rather than the element with the trigger)
  for (target = event.target; target && target != this; target = target.parentNode) {
    if (target.matches(parentClass)) {
        break;
    }
  }

  return target;
}

/**
 * Change desktop header height on scroll
 */

let lastY = window.scrollY;

document.addEventListener("scroll", function(e) {
  let scrollThreshold;

  // Check screen width to define scroll threshold for desktop and mobile
  if (window.innerWidth <= 768) { // Example: Mobile devices (you can adjust the width)
    scrollThreshold = 38; // Mobile scroll threshold
  } else {
    scrollThreshold = 100; // Desktop scroll threshold
  }

  // Add or remove the class based on the scroll position
  if (window.scrollY >= scrollThreshold) {
    document.body.classList.add('body-scrolled');
  } else {
    document.body.classList.remove('body-scrolled');
  }
}, {passive: true});

/**
 * Mobile menu
 */
let mobileMenuToggle = document.querySelector('.js-mobile-menu-toggle');
let mobileToggleIcons = mobileMenuToggle.querySelectorAll('svg');
let mobileMenu = document.querySelector('.js-mobile-menu');
let mobileSearch = document.querySelector('.js-search');

mobileMenuToggle.addEventListener("click",  function(event) {
  mobileToggleIcons.forEach(el => {
    el.classList.toggle('hidden');
  });
  if(mobileMenu.classList.contains('hidden')) {
    mobileMenu.classList.toggle('hidden');
    setTimeout(() => {
      mobileMenu.classList.toggle('translate-x-[-120vw]')
    }, 50);
  } else {
    mobileMenu.classList.toggle('translate-x-[-120vw]')
    setTimeout(() => {
      mobileMenu.classList.toggle('hidden');
    }, 300);
  }
  mobileSearch.classList.toggle('hidden');
  document.body.classList.toggle('overflow-hidden');
  window.dispatchEvent(new CustomEvent('close-search'));

  event.preventDefault();
});

// When search is togged with mobile menu open, need to force it to open and close mobile menu
window.addEventListener('toggle-search', function(e) {
  if(!mobileMenu.classList.contains('hidden')) {
    mobileMenuToggle.click();
    setTimeout(() => {
      window.dispatchEvent(new CustomEvent('force-mobile-search'));
    }, 300);
  }
});

function toggleBodyScroll(removeBodyScroll) {
  if(removeBodyScroll) {
    document.body.classList.add('overflow-hidden');
    document.body.classList.remove('md:overflow-auto');
  } else {
    document.body.classList.remove('overflow-hidden');
    document.body.classList.add('md:overflow-auto');
  }
}

/*
 * Push cart
 */
let cartIcon = document.querySelector('.js-cart-icon');

cartIcon.addEventListener("click", function(event) {
  window.dispatchEvent(new CustomEvent('show-push-cart', { detail: {}, bubbles: true }))
  event.preventDefault();
});

/*
 * Translate footwear sizes
 */
function translateRawSizeLabels() {
  let sizes = document.querySelectorAll('[data-raw-size]');

  sizes.forEach(sizeNode => {
    let label = sizeNode.dataset.rawSize;
    let newLabel = translateSize(label, sizeNode.dataset.gender);

    if(newLabel != label) {
      sizeNode.textContent = newLabel;
    }
  })
}

translateRawSizeLabels();

function translateSize(rawSize, gender) {
  let parts = rawSize.split(' ');

  if(parts[0] != 'UK' || parts.length <= 2) {
    return rawSize;
  }

  if(Shopify.currency.active == 'GBP' && parts[2] == 'EU') {
    return parts[0] + ' ' + parts[1];
  }

  if(Shopify.currency.active == 'EUR' && parts[2] == 'EU') {
    return parts[2] + ' ' + parts[3];
  }

  if(Shopify.currency.active == 'USD' || Shopify.currency.active == 'CAD') {
    if(gender == 'collection') {
      return womens_size_map[rawSize] ? womens_size_map[rawSize] : (mens_size_map[rawSize] ? mens_size_map[rawSize] : rawSize);
    }
    if(gender == 'womens') {
      return womens_size_map[rawSize] ? womens_size_map[rawSize] : rawSize;
    }

    return mens_size_map[rawSize] ? mens_size_map[rawSize] : rawSize;
  }

  return rawSize;
}

document.addEventListener('alpine:init', () => {
  /**
   * Push cart item
   */
  Alpine.data('pushCartItem', (key, quantity, giftWrapName, giftWrapMessage, vgmURL, vgmSVG) => ({
    key: key,
    disabled: false,
    showGiftWrap: false,
    quantityMessageBold: false,
    hasGiftwrap: giftWrapName != '',
    giftWrapName: giftWrapName,
    giftWrapMessage: giftWrapMessage,
    quantity: quantity,
    giftWrapError: '',

    // vgm
    locked: false,
    vgmSVG: vgmSVG,
    vgmURL: vgmURL,
    uploadFeedback:'',

    addGiftWrap: function() {

      if(this.giftWrapName == '') {
        this.giftWrapError = 'Please enter a recipient';
        setTimeout(() => this.giftWrapError = '', 3000);
        return;
      }

      // VGM video not always enabled, so check for ref. If there, only do anything if a file has been provided
      if(this.$refs.video) {
        if(this.$refs.video.files[0] && !this.vgmURL) {
          this.upload();
          return;
        }
      }

      this.change({
        'id': this.key,
        'properties': {
          'GM To': this.giftWrapName,
          'GM': this.giftWrapMessage,
          '_VGM SVG': this.vgmSVG,
          '_VGM URL': this.vgmURL,
        },
        'sections': 'push-cart,main-cart'
      });
    },

    removeGiftWrap: function() {
      this.change({
        'id': this.key,
        'properties': {
          '_GM Removed': true
        },
        'sections': 'push-cart,main-cart'
      });
    },
    flashQuantityMessage() {
      this.$data.quantityMessageBold = true;
      setTimeout(() => {
        this.$data.quantityMessageBold = false;
      }, 500);
    },
    change: function(formData, onComplete) {
      this.disabled = true;

      fetch(window.Shopify.routes.root + 'cart/change.js', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json'
        },
        body: JSON.stringify(formData)
      })
        .then(response => { return response.json();})
        .then(response => {
          if (response.status) {
            alert(response.status);
            return;
          }

          if(response.sections) {
            refreshCartMarkup(response.sections);
          }

          if(onComplete) {
            onComplete();
          }

        }).then(() => {

          let mainCartEl = document.getElementById('main-cart-inner');
          if(mainCartEl) {
            fetch(window.Shopify.routes.root + '?sections=' + mainCartEl.dataset.sectionId)
              .then(response => { return response.json();})
              .then(response => {
                mainCartEl.innerHTML = new DOMParser().parseFromString(response[mainCartEl.dataset.sectionId], 'text/html').getElementById('main-cart-inner').innerHTML;
              })
          } else {
            // NOTE: this refreshes rebuy, as the rebuy widget is readded to the dom every qty change - don't need this on main cart
            window.dispatchEvent(new CustomEvent('show-push-cart', { detail: {}, bubbles: true }));
          }
        })
        .catch((error) => {
          alert(error);
        });
    },

    setQuantity: function(qty) {
      this.change({
        'id': this.key,
        'quantity': qty,
        'sections': 'push-cart,cart-count'
      });
    },

    removeAndOptOut: function() {
      fetch(window.Shopify.routes.root + 'cart/change.js', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json'
        },
        body: JSON.stringify({
          'id': this.key,
          'quantity': 0,
        })
      })
        .then(response => { return response.json();})
        .then(response => {
          // Save the attribute
          var formData = new FormData();
          formData.append("attributes[opt_out_keyring]", 1);
          formData.append("sections", 'push-cart,main-cart');
          fetch(window.Shopify.routes.root + 'cart/update.js', {
            method: 'POST',
            body: formData
          })
            .then(response => response.json())
            .then(response => {
              if(response.sections) {
                refreshCartMarkup(response.sections);
              }
            });
        });
    },

    upload() {
      if(!this.$refs.video.files || !this.$refs.video.files.length) {
        alert("No video");
        return;
      }

      let video = this.$refs.video.files[0];
      let progressEl = this.$refs.progress;
      let progressCounter = this.$refs.progressCounter;
      let formData = new FormData();
      let friendlySize = Math.round(video.size / 1024 / 1024);

      if(friendlySize > 101) {
        this.uploadFeedback = 'Video is too large. Maxium size is 100MB, your video is ' + friendlySize + 'MB';
        setTimeout(() => this.uploadFeedback = '', 3000);
        return;
      }

      this.locked = true;
      formData.append("video", video);
      var req = new XMLHttpRequest();

      req.upload.addEventListener('progress', function (e) {
        var file1Size = video.size;
        console.log(file1Size);

        if (e.loaded <= file1Size) {
            var percent = Math.round(e.loaded / file1Size * 100);
            progressEl.style.width = percent + '%';
            progressCounter.innerHTML = percent + '%';
        }

        if(e.loaded == e.total){
            progressEl.style.width = '100%';
            progressCounter.innerHTML = 'Processing...';
        }
      });

      var that = this;

      req.onreadystatechange = function() {
        if (this.readyState == 4 && this.status == 200) {
          var response = JSON.parse(this.responseText);
          that.locked = false;
          if(response.feedback.hasOwnProperty('error')) {
            that.uploadFeedback = response.feedback.message;
          } else {
            that.vgmSVG = response.feedback.data.qr_code.svg_image_url;
            that.vgmURL = response.feedback.data.landing_page.url;
            progressEl.innerHTML = 'Complete!';
            that.addGiftWrap();
          }
        }
      };

      req.open('post', 'https://fafv2.trsdesign.com/api/vgm');
      req.timeout = 45000;
      req.send(formData);
    },

    removeVideo() {
      if(this.vgmSVG != '') {
        this.change({
          'id': this.key,
          'properties': {
            'GM To': this.giftWrapName,
            'GM': this.giftWrapMessage,
            '_GM Video Removed': true
          },
          'sections': 'push-cart,main-cart'
        }, () => {
          this.vgmSVG = '';
          this.vgmUrl = '';
        });
      }
    }

  }))

  /**
   * Carousel, with filter option
   */
  Alpine.data('carousel', (loaded = true) => ({
    tag: '',
    leftActive: false,
    loaded: loaded,
    rightActive: true,
    asyncItems: [],
    empty: false,
    percentageScroll: 0,
    scroll(direction) {
      let width = this.$refs.slider.offsetWidth;
      let currentPosition = this.$refs.slider.scrollLeft;
      this.$refs.slider.scrollTo({ left: direction == 'left' ? currentPosition - width : currentPosition + width, behavior: 'smooth' });
    },

    updateArrows() {
      this.$data.rightActive = (this.$refs.slider.scrollLeft + this.$refs.slider.offsetWidth) < this.$refs.slider.scrollWidth;
      this.$data.leftActive = this.$refs.slider.scrollLeft > 0;
      this.$data.percentageScroll = this.$refs.slider.scrollLeft / this.$refs.slider.scrollWidth;
    },

    filter(tag) {
      if(this.$data.tag == tag) {
        return;
      }

      this.$data.tag = tag;
      this.$refs.slider.querySelectorAll('[data-tags]').forEach(el => {
        el.classList.remove('hidden');
        let tags = JSON.parse(el.dataset.tags);
        if(tags.indexOf(tag) != -1 || tag == '') {
          el.classList.remove('hidden');
        } else {
          el.classList.add('hidden');
        }
      });

      this.$refs.slider.scrollTo({ left: 0, behavior: 'smooth' });
    },

    load(url, parser) {
      fetch(url)
        .then(response => { return response.json();})
        .then(response => {
          this.$data.asyncItems = parser(response).filter(p => p);
          this.$data.loaded = true;
          if(this.$data.asyncItems.length == 0) {
            this.$data.empty = true;
          }
        });
    },
    scrollTo(scrollPercentage) {
      this.$refs.slider.scrollTo({ left: scrollPercentage * this.$refs.slider.scrollWidth, behavior: 'smooth' });
    }
  }));

  /**
   * Popup for mobile quick add
   */
  Alpine.data('popupAdd', (loaded = true) => ({
    open: false,
    loaded: false,
    init() {
      this.$watch('open', (v) => {
        if(v) {
          document.body.classList.add('overflow-hidden', 'md:overflow-auto');
        } else {
          document.body.classList.remove('overflow-hidden', 'md:overflow-auto');
          this.loaded = false;
        }
      })
    },
    reveal($event) {
      let handle = $event.detail.handle;
      this.open = true;
      fetch(window.Shopify.routes.root + 'products/'+handle+'?view=mobile-quick-add').then(res => {
        return res.text();
      }).then(res => {
        this.$refs.content.innerHTML = res;
        this.$nextTick(() => this.loaded = true);
      });
    }
  }));

  /*
   * In the mobile popup, validate size selection
   */
  Alpine.data('quickPopProduct', () => ({
    error: '',
    add() {
      if(!this.$refs.variant_id.value) {
        this.error = 'Please select size';
        setTimeout(() => {
          this.error = '';
        }, 2000);
        return;
      }
      addVariantToCart(this.$refs.variant_id.value, () => { this.$dispatch('close-popup-add') });
    }
  }));

  /**
   * Lazy carousel - wrapper around carousel with fetch collection
   */
   Alpine.data('lazyCarousel', (handle) => ({
    lazyMarkup: '',
    lazyLoaded: false,
    handle: handle,
    load() {
      fetch('/collections/' + this.handle + '?view=carousel&limit=20')
        .then(response => response.text())
        .then(text => {
          this.$data.lazyMarkup = new DOMParser().parseFromString(text, 'text/html').getElementById('carousel-content').innerHTML;
          this.$data.lazyLoaded = true;
        });
    }
  }));

  /**
   * Tassel upsell - global as included in push cart
   */
  Alpine.data('tasselUpsell', (tasselImage) => ({
    selected: '',
    adding: false,
    price: '',
    tasselImage: tasselImage,
    add() {
      this.$data.adding = true;
      addVariantToCart(this.selected, () => {
        this.$data.adding = false;
      });
    }
  }));

  /**
   * Alibi in push cart
   */
  Alpine.data('alibi', (id = '') => ({
    open: false,
    alibi: '',
    id: id,
    init() {

      this.$watch('open', () => {
        document.querySelectorAll('.js-alibi-toggle').forEach(node => {
          node.classList.toggle('hidden');
        })
      });
    },
    save() {
      if (this.alibi == 'gift') {
        addVariantToCart(39337899884616, () => { })
      }

      if (this.alibi == 'comp') {
        addVariantToCart(39429425266760, () => { })
      }
    },
    remove() {
      fetch(window.Shopify.routes.root + 'cart/change.js', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json'
        },
        body: JSON.stringify({
          'id': this.id,
          'quantity': 0,
          'sections': 'push-cart,main-cart,cart-count'
        })
      })
        .then(response => { return response.json(); })
        .then(response => {
          if (response.status) {
            alert(response.status);
            return;
          }

          if(response.sections) {
            refreshCartMarkup(response.sections);
          }
        })
        .catch((error) => {
          alert(error);
        });
    }
  }));

  /**
   * Add discount via push cart
   */
  Alpine.data('pushDiscounts', (codes, open) => ({
    codes: codes,
    open: open,
    locked: false,
    codeToAdd: '',
    error: '',

    setError(msg, timeout) {
      this.error = msg;
      setTimeout(() => this.error = '', timeout ?? 1500);
    },

    applyNew() {
      if(!this.codeToAdd) {
        this.setError('Discount code empty');
        return;
      }
      let newCodes = [...this.codes, this.codeToAdd];
      this.updateDiscount(newCodes.join(','));
    },

    removeDiscount(code) {
      let newCodes = this.codes.filter(c => c !== code);
      this.updateDiscount(newCodes.join(','));
    },

    updateDiscount(codes) {

      this.locked = true;

      fetch(window.Shopify.routes.root + 'cart/update.js', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/x-www-form-urlencoded;charset=UTF-8'
        },
        body: 'discount=' + codes + '&sections=push-cart,cart-count'
      })
        .then(response => { return response.json();})
        .then(response => {

          this.locked = false;

          if (response.status) {
            alert(response.status);
            return;
          }

          if(this.codeToAdd) {
            let added = response.discount_codes.filter(c => c.code === this.codeToAdd);
            if(added.length && !added[0].applicable) {
              this.setError("Failed to add code '" + this.codeToAdd + "'", 3000);
              return;
            }
          }

          refreshCartMarkup(response.sections);
        });
    }
  }));


  /**
   * Global search
   */
  Alpine.data('search', () => ({
    init() {
      this.$watch('term', () => {
        if(this.$data.term == '') {
          this.$data.searched = false;
        } else {
          this.search();
        }
      })
    },
    show: false, // Used on search focus
    searched: false, // Used to swap between a search and the on focus suggestions
    term: '',
    algoliaUrl: 'https://ur659mj8u0-dsn.algolia.net/1/indexes/*/queries?x-algolia-api-key=86eb7cd2741a090dced520f9f3f2029e&x-algolia-application-id=UR659MJ8U0',
    totals: {
      products: 0,
      suggestions: 0,
      faqs: 0,
      articles: 0,
    },
    products: [],
    suggestions: [],
    productQueryID: '',
    faqs: [],
    articles: [],
    pages: [],
    desktopTab: 'products',
    search() {

      window.dataLayer.push({
        algoliaIndexName: 'shopify_products'
      });

      let filters = '';

      if(typeof searchFilter != 'undefined') {
        filters = 'NOT tags:' + searchFilter;
      }

      let searchParams = new URLSearchParams({
        'facetingAfterDistinct': true,
        'distinct': 1,
        'hitsPerPage': 4,
        'filters': filters,
        'query': this.$data.term,
        'clickAnalytics': true,
      }).toString();

      let pageSearchParams = new URLSearchParams({
        'facetingAfterDistinct': true,
        'distinct': 1,
        'hitsPerPage': 4,
        'filters': 'NOT template_suffix:size-guide AND NOT handle:avada-sitemap-blogs',
        'query': this.$data.term,
        'clickAnalytics': true,
      }).toString();

      let search = {"requests":[
        {"indexName":"shopify_products", "params": searchParams },
        {"indexName":"shopify_products_query_suggestions", "params": searchParams },
        {"indexName":"trs_customer_service_infos", "params": searchParams },
        {"indexName":"shopify_articles", "params": searchParams },
        {"indexName":"shopify_pages", "params": pageSearchParams },
      ]};

      fetch(this.$data.algoliaUrl, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json'
        },
        body: JSON.stringify(search)
      })
        .then(response => { return response.json();})
        .then(response => {
          this.$data.products = response.results[0].hits;
          this.$data.totals.products = response.results[0].nbHits;

          this.$data.productQueryID = response.results[0].queryID;

          this.$data.suggestions = response.results[1].hits;
          this.$data.totals.suggestions = response.results[1].nbHits;

          this.$data.faqs = response.results[2].hits;
          this.$data.totals.faqs = response.results[2].nbHits;

          this.$data.articles = response.results[3].hits;
          this.$data.totals.articles = response.results[3].nbHits;

          this.$data.pages = response.results[4].hits;
          this.$data.totals.pages = response.results[4].nbHits;

          this.$data.searched = true;
        });
    },
    getPrice(price, nativePrice) {
      if(nativePrice) {
        return parseInt(nativePrice).toFixed(2).replace('.00', '');
      }

      if(Shopify.currency.rate == '1.0') {
          if((price * 100) % 100 == 0) {
              return price;
          }

          return price.toFixed(2);
      }

      // Other currency always rounds up
      return Math.ceil(price * Shopify.currency.rate)
    }
  }));

  /*
    * Delievery countdown: used in push cart and on product details
    */
  Alpine.data('countdown', () => {
    return {
      init() {
        setInterval(() => this.tick(), 60000);
        this.tick();
      },
      tick() {
        let now = new Date(),
            cutoff = new Date(),
            arrival = new Date(),
            days = ["Sunday", "Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday"],
            hasGiftwrap = false,
            hourCutoff = 16,
            wantIt = '';

        // @TODO: For gift wrap orders, travel forwards 2 days, and subtract 48 hours off the order by time
        if(hasGiftwrap) {
            now.setDate(now.getDate() + 2);
        }

        let dow = now.getDay();

        // If we are past 2pm (or saturday / sunday), then arrival (at best) is not tomorrow, but next day
        if(now.getHours() >= hourCutoff || dow == 0 || dow == 6) {
            // After 2pm on a friday - delivery is tuesday (4 days away)
            if(dow == 5) {
                extraDay = 2;
            } else {
                extraDay = dow == 6 ? 1 : 0; // sat needs an extra day
            }

            if(dow == 4) {
                this.showSaturday = true;
            }

            arrival.setDate(now.getDate() + 2 + extraDay);
            cutoff.setDate(now.getDate() + 1 + extraDay);
            cutoff.setHours(hourCutoff);
            cutoff.setMinutes(0);
            cutoff.setSeconds(0);
        } else {
          if(dow == 5) {
              this.showSaturday = true;
          }
          arrival.setDate(now.getDate() + 1);
          cutoff.setDate(now.getDate());
          cutoff.setHours(hourCutoff);
          cutoff.setMinutes(0);
          cutoff.setSeconds(0);
        }

        diff = ((cutoff.getTime() - now.getTime()) / 1000);
        wantIt = cutoff.getDate() == now.getDate() ? 'tomorrow' : days[arrival.getDay()];
        days = parseInt(Math.floor(diff / 86400));
        hours = parseInt(Math.floor(diff / 3600)  % 24);
        mins = ('0' + parseInt(Math.floor((diff % 3600) / 60))).substr(-2);
        seconds = ('0' + parseInt(diff % 60)).substr(-2);

        days = days > 0 ? days + ' days ' : '';

        if(hasGiftwrap) {
            hours = hours - 48;
        }

        this.days = 'by ' + wantIt;
        this.text = 'Order in the next ' + days + hours + ' hrs ' + mins + ' mins';

      },
      days: '',
      text: '',
      showSaturday: false
    }
  });

  Alpine.data('simpleCountdown', (targetDate, showSeconds) => {
    return {
      targetDate: targetDate,
      showSeconds: showSeconds,
      init() {
        setInterval(() => this.tick(), 1000);
        this.tick();
      },
      tick() {
        let now = new Date(),
            cutoff = new Date(this.targetDate),
            diff = ((cutoff.getTime() - now.getTime()) / 1000);

        days = parseInt(Math.floor(diff / 86400));
        hours = parseInt(Math.floor(diff / 3600) % 24);
        total_hours = parseInt(Math.floor(diff / 3600));
        mins = ('0' + parseInt(Math.floor((diff % 3600) / 60))).substr(-2);
        total_mins = parseInt(Math.floor((diff / 60)));
        seconds = ('0' + parseInt(diff % 60)).substr(-2);

        if(this.showSeconds) {
          this.text = total_mins + ' mins ' + seconds + ' sec';
        } else {
          this.text = days + ' days ' + hours + ' hrs ' + mins + ' mins';
        }
      },
      text: ''
    }
  });

    Alpine.data('secondCountdown', (targetDate, showSeconds) => {
    return {
      targetDate: targetDate,
      showSeconds: showSeconds,
      init() {
        setInterval(() => this.tick(), 1000);
        this.tick();
      },
      tick() {
        let now = new Date(),
            cutoff = new Date(this.targetDate),
            diff = ((cutoff.getTime() - now.getTime()) / 1000);

        days = parseInt(Math.floor(diff / 86400));
        hours = parseInt(Math.floor(diff / 3600) % 24);
        total_hours = parseInt(Math.floor(diff / 3600));
        mins = ('0' + parseInt(Math.floor((diff % 3600) / 60))).substr(-2);
        total_mins = parseInt(Math.floor((diff / 60)));
        seconds = ('0' + parseInt(diff % 60)).substr(-2);

        if(this.showSeconds) {
          this.text = total_mins + ' mins ' + seconds + ' sec';
        } else {
          this.text = hours + ' hrs ' + mins + ' mins ' + seconds + ' sec';
        }
      },
      text: ''
    }
  });

  Alpine.data('simpleMilli', () => {
    return {
      init() {
        setInterval(() => this.tick(), 100);
        this.tick();
      },
      tick() {
        this.text = ('0' + (100 - parseInt(new Date().getMilliseconds() / 10))).substr(-2) + ' ';
      },
      text: ''
    }
  });

  /*
   * Wishlist store
   */
  Alpine.store('wishlist', {
		products: storedWishlist,
		handles: [],

    init() {
			this.handles = Object.keys(this.products);

      if(typeof forceWishlistResync !== 'undefined' && forceWishlistResync) {
        console.log("Resync wishlist");
        this.persist();
      }

      if(this.handles.length) {
        document.querySelector('.js-wishlist-count').innerText = this.handles.length;
        document.querySelector('.js-wishlist-count').classList.remove('hidden');
      }
    },

		toggle: function (handle, variantId = 0) {
			if (this.hasProduct(handle)) {
				delete this.products[handle];
				this.handles.splice(this.handles.indexOf(handle), 1);
			} else {
				this.products[handle] = variantId;
				this.handles.push(handle);
			}

			localStorage.setItem('faf-wish-list', JSON.stringify(this.products))
			this.persist();
		},
		hasProduct: function (handle) {
			return this.handles.indexOf(handle) > -1;
		},
		persist() {
			if (typeof customerId !== 'undefined') {
        fetch('https://fafv2.trsdesign.com/api/wishlist', {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json'
          },
          body: JSON.stringify({ wishlist: this.products, customerId: customerId })
        })
			}
		}
  });


  Alpine.data('confidenceBuilder', (slideCount) => ({
    currentSlide: 0,
    slideCount: slideCount,
    interval: '',
    init() {
      this.$data.createInterval();
    },
    createInterval() {
      this.$data.interval = setInterval(() => {
        this.setSlide(this.$data.currentSlide + 1);
      }, 5000);
    },
    setSlide(index, resetInterval = false) {
      this.$data.currentSlide = index % this.$data.slideCount;
      if(resetInterval) {
        this.$data.resetInterval();
      }
    },
    resetInterval() {
      clearInterval(this.$data.interval);
      this.$data.createInterval();
    }
  }));


  Alpine.data('gifImage', (slideCount) => ({
    currentSlide: 0,
    slideCount: slideCount,
    interval: '',
    init() {
      this.$data.createInterval();
    },
    createInterval() {
      this.$data.interval = setInterval(() => {
        this.setSlide(this.$data.currentSlide + 1);
      }, 2000);
    },
    setSlide(index, resetInterval = false) {
      this.$data.currentSlide = index % this.$data.slideCount;
      if(resetInterval) {
        this.$data.resetInterval();
      }
    },
    resetInterval() {
      clearInterval(this.$data.interval);
      this.$data.createInterval();
    }
  }));

    Alpine.data('productSync', (updates) => ({
    updates: updates,
    init() {
      fetch(window.Shopify.routes.root + 'cart/update.js', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/x-www-form-urlencoded;charset=UTF-8'
        },
        body: this.updates + '&sections=push-cart,cart-count'
      })
        .then(response => { return response.json();})
        .then(response => {
          if (response.status) {
            alert(response.status);
            return;
          }

          refreshCartMarkup(response.sections);
        });
    }
  }));


  Alpine.data('giftWrapSync', (bags, wrap) => ({
    bags: bags,
    wrap: wrap,
    init() {
      fetch(window.Shopify.routes.root + 'cart/update.js', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/x-www-form-urlencoded;charset=UTF-8'
        },
        body: 'updates[39367888568392]='+this.wrap+'&updates[39944066302024]='+this.bags+'&updates[39432779399240]=' + (this.bags + this.wrap) + '&sections=push-cart,cart-count'
      })
        .then(response => { return response.json();})
        .then(response => {
          if (response.status) {
            alert(response.status);
            return;
          }

          refreshCartMarkup(response.sections);
        });
    }
  }));

  Alpine.data('newsletter', (endpoint) => ({
    endpoint: endpoint,
    error: '',
    sent: false,
    submit() {
      if(!this.$refs.newsletterForm.reportValidity()) {
        return;
      }

      let formData = new FormData(this.$refs.newsletterForm);
      let formPostData = new URLSearchParams(formData).toString();

      fetch(this.endpoint, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/x-www-form-urlencoded'
        },
        body: formPostData
      })
        .then(response => { return response.json();})
        .then(response => {
          this.sent = true;
        }).catch((error) => {
          this.error = error;
          setTimeout(() => this.error = '', 5000);
        });

    }
  }));

  Alpine.data('shareModal', (title,description, url, context) => ({
    open: false,
    context: context,
    launch: function(url) {

      // Some shares append dynamic values
      if(url) {
        this.url = url;
      }

      if(navigator && navigator.share && ('ontouchstart' in window || navigator.msMaxTouchPoints)) {
        navigator.share({ title: this.title, 'text': this.url });
      } else {
        this.open = true;
      }
    },
    title: title,
    description: description,
    url: url,
    urls: {
      facebook: 'https://www.facebook.com/sharer/sharer.php?u=[URL]&title=[TITLE]&description=[DESCRIPTION]',
      twitter: 'https://twitter.com/intent/tweet?text=[DESCRIPTION] [URL]',
      mail: 'mailto:?body=[URL]&subject=[DESCRIPTION]',
      pinterest: 'https://pinterest.com/pin/create/bookmarklet/?url=[URL]&description=[DESCRIPTION]',
      whatsapp: 'https://api.whatsapp.com/send?text=[DESCRIPTION] [URL]'
    },
    shareUrl: function(url) {
      return url.replace('[DESCRIPTION]', this.description)
        .replace('[TITLE]', this.title)
        .replace('[URL]', this.url)
    },
    track(method) {
      if(gtag && this.context) {
        gtag('event', 'shared', { method: method, context: this.context });
        console.log(method);
      }
    },
    copy: function() {
      var copyUrl = this.$refs.copyUrl;
      copyUrl.focus();
      copyUrl.select();
      document.execCommand('copy');
      this.track('manual copy');
    }
  }));

  Alpine.data('quickAddToBag', () => ({
    init() {
      this.$watch('variantId', (v) => {
        if(v) {
          this.addButtonText = 'Add to bag';
        } else {
          this.addButtonText = 'Select Size';
        }
      })
    },
    variantId: '',
    showMobile: false,
    addButtonText: 'Select Size',
    addSingleButtonText: 'Add to bag',
    add() {
      if(this.variantId == '') {
        this.showMobile = !this.showMobile;
      } else {
        this.addButtonText = 'Adding...';
        addVariantToCart(this.variantId, () => {
          this.showMobile = false;
          this.variantId = '';
        });
      }
    },

    addVariant(id) {
      this.addSingleButtonText = 'Adding...';
      addVariantToCart(id, () => {
        this.showMobile = false;
        this.addSingleButtonText = 'Add to bag';
      });
    }
  }));

  /*
   * Freee gift choice popup
   */
  Alpine.data('offerPopup', () => ({
    showOffer: true,
    setOptOut() {
      fetch(window.Shopify.routes.root + 'cart.js', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          'attributes': {
            'opt_out_keyring': 1
          }
        })
      })
    }
  }));

  Alpine.data('simpleDotScroller', (slideCount) => ({
    scrollPercent: 0,
    dotIndex: 1,
    slideCount: slideCount,
    updateDots() {
      this.$data.scrollPercent = this.$refs.slider.scrollLeft / this.$refs.slider.scrollWidth;
      this.$data.dotIndex = Math.round(this.$data.scrollPercent * this.$data.slideCount) + 1;
    },
    scrollTo(index) {
      this.$refs.slider.scrollTo({ left: ((index - 1) / this.slideCount) * this.$refs.slider.scrollWidth, behavior: 'smooth' });
    }
  }));

});

function refreshCartMarkup(sections) {
  if(sections['push-cart']) {
    document.getElementById('shopify-section-push-cart').innerHTML = new DOMParser().parseFromString(sections['push-cart'], 'text/html').getElementById('shopify-section-push-cart').innerHTML;
  }

  if(sections['cart-count']) {
    document.querySelector('.js-cart-count').innerHTML = sections['cart-count'];
  }
}



/**
 * Generic add to cart, and toggle push cart
 */
function addVariantToCart(variantId, onComplete, properties, extraItems) {
  let formData = {
    'items': [{
      'id': variantId,
      'quantity': 1
    }],
    'sections': 'push-cart,cart-count'
  };

  if(extraItems) {
    formData['items'].push(...extraItems);
  }

  if(properties) {
    formData['items'][0]['properties'] = properties;
  }

  fetch(window.Shopify.routes.root + 'cart/add.js', {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json'
    },
    body: JSON.stringify(formData)
  })
    .then(response => { return response.json();})
    .then(response => {
      if (response.status) {
        if(response.status == 422) {
          throw new Error('Not enough stock');
        }
        return;
      }

      document.getElementById('shopify-section-push-cart').innerHTML = new DOMParser().parseFromString(response.sections['push-cart'], 'text/html').getElementById('shopify-section-push-cart').innerHTML;
      document.querySelector('.js-cart-count').innerHTML = response.sections['cart-count'];
      document.querySelector('.js-cart-count').classList.remove('hidden');
    })
    .then(() => {
      // Don't pop push cart if on main cart + re-fetch main cart
      let mainCartEl = document.getElementById('main-cart-inner');
      if(mainCartEl) {
        fetch(window.Shopify.routes.root + '?sections=' + mainCartEl.dataset.sectionId)
          .then(response => { return response.json();})
          .then(response => {
            mainCartEl.innerHTML = new DOMParser().parseFromString(response[mainCartEl.dataset.sectionId], 'text/html').getElementById('main-cart-inner').innerHTML;
          })
      } else {
        window.dispatchEvent(new CustomEvent('show-push-cart', { detail: {}, bubbles: true }));
      }

      if(typeof item === "object" && typeof _learnq == "object") {
        _learnq.push(['track', 'Added to Cart', item]);
      }

      if(onComplete) {
        onComplete();
      }
    })
    .catch((error) => {
      if(onComplete) {
        onComplete(error);
      } else {
        alert(error);
      }
    });
}

function openSizes() {

}

function getSizedImage(src, size) {
  return src.replace(/_(pico|icon|thumb|small|compact|medium|large|grande|original|1024x1024|2048x2048|master)+\./g, '.')
    .replace(/\.jpg|\.png|\.gif|\.jpeg/g, function(match) {
      return '_'+size+match;
    });
}

function getImageSrcset(src, sizes) {
  return sizes.map(w => {
    return getSizedImage(src, w + 'x') + ' ' + w + 'w';
  }).join(', ');
}

function setClipboard(value) {
    var tempInput = document.createElement("input");
    tempInput.style = "position: absolute; left: -1000px; top: -1000px";
    tempInput.value = value;
    document.body.appendChild(tempInput);
    tempInput.select();
    document.execCommand("copy");
    document.body.removeChild(tempInput);
}

/*! lazysizes - v5.3.2 */
!function(e){var t=function(u,D,f){"use strict";var k,H;if(function(){var e;var t={lazyClass:"lazyload",loadedClass:"lazyloaded",loadingClass:"lazyloading",preloadClass:"lazypreload",errorClass:"lazyerror",autosizesClass:"lazyautosizes",fastLoadedClass:"ls-is-cached",iframeLoadMode:0,srcAttr:"data-src",srcsetAttr:"data-srcset",sizesAttr:"data-sizes",minSize:40,customMedia:{},init:true,expFactor:1.5,hFac:.8,loadMode:2,loadHidden:true,ricTimeout:0,throttleDelay:125};H=u.lazySizesConfig||u.lazysizesConfig||{};for(e in t){if(!(e in H)){H[e]=t[e]}}}(),!D||!D.getElementsByClassName){return{init:function(){},cfg:H,noSupport:true}}var O=D.documentElement,i=u.HTMLPictureElement,P="addEventListener",$="getAttribute",q=u[P].bind(u),I=u.setTimeout,U=u.requestAnimationFrame||I,o=u.requestIdleCallback,j=/^picture$/i,r=["load","error","lazyincluded","_lazyloaded"],a={},G=Array.prototype.forEach,J=function(e,t){if(!a[t]){a[t]=new RegExp("(\\s|^)"+t+"(\\s|$)")}return a[t].test(e[$]("class")||"")&&a[t]},K=function(e,t){if(!J(e,t)){e.setAttribute("class",(e[$]("class")||"").trim()+" "+t)}},Q=function(e,t){var a;if(a=J(e,t)){e.setAttribute("class",(e[$]("class")||"").replace(a," "))}},V=function(t,a,e){var i=e?P:"removeEventListener";if(e){V(t,a)}r.forEach(function(e){t[i](e,a)})},X=function(e,t,a,i,r){var n=D.createEvent("Event");if(!a){a={}}a.instance=k;n.initEvent(t,!i,!r);n.detail=a;e.dispatchEvent(n);return n},Y=function(e,t){var a;if(!i&&(a=u.picturefill||H.pf)){if(t&&t.src&&!e[$]("srcset")){e.setAttribute("srcset",t.src)}a({reevaluate:true,elements:[e]})}else if(t&&t.src){e.src=t.src}},Z=function(e,t){return(getComputedStyle(e,null)||{})[t]},s=function(e,t,a){a=a||e.offsetWidth;while(a<H.minSize&&t&&!e._lazysizesWidth){a=t.offsetWidth;t=t.parentNode}return a},ee=function(){var a,i;var t=[];var r=[];var n=t;var s=function(){var e=n;n=t.length?r:t;a=true;i=false;while(e.length){e.shift()()}a=false};var e=function(e,t){if(a&&!t){e.apply(this,arguments)}else{n.push(e);if(!i){i=true;(D.hidden?I:U)(s)}}};e._lsFlush=s;return e}(),te=function(a,e){return e?function(){ee(a)}:function(){var e=this;var t=arguments;ee(function(){a.apply(e,t)})}},ae=function(e){var a;var i=0;var r=H.throttleDelay;var n=H.ricTimeout;var t=function(){a=false;i=f.now();e()};var s=o&&n>49?function(){o(t,{timeout:n});if(n!==H.ricTimeout){n=H.ricTimeout}}:te(function(){I(t)},true);return function(e){var t;if(e=e===true){n=33}if(a){return}a=true;t=r-(f.now()-i);if(t<0){t=0}if(e||t<9){s()}else{I(s,t)}}},ie=function(e){var t,a;var i=99;var r=function(){t=null;e()};var n=function(){var e=f.now()-a;if(e<i){I(n,i-e)}else{(o||r)(r)}};return function(){a=f.now();if(!t){t=I(n,i)}}},e=function(){var v,m,c,h,e;var y,z,g,p,C,b,A;var n=/^img$/i;var d=/^iframe$/i;var E="onscroll"in u&&!/(gle|ing)bot/.test(navigator.userAgent);var _=0;var w=0;var M=0;var N=-1;var L=function(e){M--;if(!e||M<0||!e.target){M=0}};var x=function(e){if(A==null){A=Z(D.body,"visibility")=="hidden"}return A||!(Z(e.parentNode,"visibility")=="hidden"&&Z(e,"visibility")=="hidden")};var W=function(e,t){var a;var i=e;var r=x(e);g-=t;b+=t;p-=t;C+=t;while(r&&(i=i.offsetParent)&&i!=D.body&&i!=O){r=(Z(i,"opacity")||1)>0;if(r&&Z(i,"overflow")!="visible"){a=i.getBoundingClientRect();r=C>a.left&&p<a.right&&b>a.top-1&&g<a.bottom+1}}return r};var t=function(){var e,t,a,i,r,n,s,o,l,u,f,c;var d=k.elements;if((h=H.loadMode)&&M<8&&(e=d.length)){t=0;N++;for(;t<e;t++){if(!d[t]||d[t]._lazyRace){continue}if(!E||k.prematureUnveil&&k.prematureUnveil(d[t])){R(d[t]);continue}if(!(o=d[t][$]("data-expand"))||!(n=o*1)){n=w}if(!u){u=!H.expand||H.expand<1?O.clientHeight>500&&O.clientWidth>500?500:370:H.expand;k._defEx=u;f=u*H.expFactor;c=H.hFac;A=null;if(w<f&&M<1&&N>2&&h>2&&!D.hidden){w=f;N=0}else if(h>1&&N>1&&M<6){w=u}else{w=_}}if(l!==n){y=innerWidth+n*c;z=innerHeight+n;s=n*-1;l=n}a=d[t].getBoundingClientRect();if((b=a.bottom)>=s&&(g=a.top)<=z&&(C=a.right)>=s*c&&(p=a.left)<=y&&(b||C||p||g)&&(H.loadHidden||x(d[t]))&&(m&&M<3&&!o&&(h<3||N<4)||W(d[t],n))){R(d[t]);r=true;if(M>9){break}}else if(!r&&m&&!i&&M<4&&N<4&&h>2&&(v[0]||H.preloadAfterLoad)&&(v[0]||!o&&(b||C||p||g||d[t][$](H.sizesAttr)!="auto"))){i=v[0]||d[t]}}if(i&&!r){R(i)}}};var a=ae(t);var S=function(e){var t=e.target;if(t._lazyCache){delete t._lazyCache;return}L(e);K(t,H.loadedClass);Q(t,H.loadingClass);V(t,B);X(t,"lazyloaded")};var i=te(S);var B=function(e){i({target:e.target})};var T=function(e,t){var a=e.getAttribute("data-load-mode")||H.iframeLoadMode;if(a==0){e.contentWindow.location.replace(t)}else if(a==1){e.src=t}};var F=function(e){var t;var a=e[$](H.srcsetAttr);if(t=H.customMedia[e[$]("data-media")||e[$]("media")]){e.setAttribute("media",t)}if(a){e.setAttribute("srcset",a)}};var s=te(function(t,e,a,i,r){var n,s,o,l,u,f;if(!(u=X(t,"lazybeforeunveil",e)).defaultPrevented){if(i){if(a){K(t,H.autosizesClass)}else{t.setAttribute("sizes",i)}}s=t[$](H.srcsetAttr);n=t[$](H.srcAttr);if(r){o=t.parentNode;l=o&&j.test(o.nodeName||"")}f=e.firesLoad||"src"in t&&(s||n||l);u={target:t};K(t,H.loadingClass);if(f){clearTimeout(c);c=I(L,2500);V(t,B,true)}if(l){G.call(o.getElementsByTagName("source"),F)}if(s){t.setAttribute("srcset",s)}else if(n&&!l){if(d.test(t.nodeName)){T(t,n)}else{t.src=n}}if(r&&(s||l)){Y(t,{src:n})}}if(t._lazyRace){delete t._lazyRace}Q(t,H.lazyClass);ee(function(){var e=t.complete&&t.naturalWidth>1;if(!f||e){if(e){K(t,H.fastLoadedClass)}S(u);t._lazyCache=true;I(function(){if("_lazyCache"in t){delete t._lazyCache}},9)}if(t.loading=="lazy"){M--}},true)});var R=function(e){if(e._lazyRace){return}var t;var a=n.test(e.nodeName);var i=a&&(e[$](H.sizesAttr)||e[$]("sizes"));var r=i=="auto";if((r||!m)&&a&&(e[$]("src")||e.srcset)&&!e.complete&&!J(e,H.errorClass)&&J(e,H.lazyClass)){return}t=X(e,"lazyunveilread").detail;if(r){re.updateElem(e,true,e.offsetWidth)}e._lazyRace=true;M++;s(e,t,r,i,a)};var r=ie(function(){H.loadMode=3;a()});var o=function(){if(H.loadMode==3){H.loadMode=2}r()};var l=function(){if(m){return}if(f.now()-e<999){I(l,999);return}m=true;H.loadMode=3;a();q("scroll",o,true)};return{_:function(){e=f.now();k.elements=D.getElementsByClassName(H.lazyClass);v=D.getElementsByClassName(H.lazyClass+" "+H.preloadClass);q("scroll",a,true);q("resize",a,true);q("pageshow",function(e){if(e.persisted){var t=D.querySelectorAll("."+H.loadingClass);if(t.length&&t.forEach){U(function(){t.forEach(function(e){if(e.complete){R(e)}})})}}});if(u.MutationObserver){new MutationObserver(a).observe(O,{childList:true,subtree:true,attributes:true})}else{O[P]("DOMNodeInserted",a,true);O[P]("DOMAttrModified",a,true);setInterval(a,999)}q("hashchange",a,true);["focus","mouseover","click","load","transitionend","animationend"].forEach(function(e){D[P](e,a,true)});if(/d$|^c/.test(D.readyState)){l()}else{q("load",l);D[P]("DOMContentLoaded",a);I(l,2e4)}if(k.elements.length){t();ee._lsFlush()}else{a()}},checkElems:a,unveil:R,_aLSL:o}}(),re=function(){var a;var n=te(function(e,t,a,i){var r,n,s;e._lazysizesWidth=i;i+="px";e.setAttribute("sizes",i);if(j.test(t.nodeName||"")){r=t.getElementsByTagName("source");for(n=0,s=r.length;n<s;n++){r[n].setAttribute("sizes",i)}}if(!a.detail.dataAttr){Y(e,a.detail)}});var i=function(e,t,a){var i;var r=e.parentNode;if(r){a=s(e,r,a);i=X(e,"lazybeforesizes",{width:a,dataAttr:!!t});if(!i.defaultPrevented){a=i.detail.width;if(a&&a!==e._lazysizesWidth){n(e,r,i,a)}}}};var e=function(){var e;var t=a.length;if(t){e=0;for(;e<t;e++){i(a[e])}}};var t=ie(e);return{_:function(){a=D.getElementsByClassName(H.autosizesClass);q("resize",t)},checkElems:t,updateElem:i}}(),t=function(){if(!t.i&&D.getElementsByClassName){t.i=true;re._();e._()}};return I(function(){H.init&&t()}),k={cfg:H,autoSizer:re,loader:e,init:t,uP:Y,aC:K,rC:Q,hC:J,fire:X,gW:s,rAF:ee}}(e,e.document,Date);e.lazySizes=t,"object"==typeof module&&module.exports&&(module.exports=t)}("undefined"!=typeof window?window:{});

/*! lazysizes - v5.3.0 - RIAS */
!function(t,e){var r=function(){e(t.lazySizes),t.removeEventListener("lazyunveilread",r,!0)};e=e.bind(null,t,t.document),"object"==typeof module&&module.exports?e(require("lazysizes")):"function"==typeof define&&define.amd?define(["lazysizes"],e):t.lazySizes?r():t.addEventListener("lazyunveilread",r,!0)}(window,function(f,u,g){"use strict";var b,m,i=g.cfg,d={string:1,number:1},l=/^\-*\+*\d+\.*\d*$/,p=/^picture$/i,v=/\s*\{\s*width\s*\}\s*/i,y=/\s*\{\s*height\s*\}\s*/i,h=/\s*\{\s*([a-z0-9]+)\s*\}\s*/gi,z=/^\[.*\]|\{.*\}$/,A=/^(?:auto|\d+(px)?)$/,w=u.createElement("a"),t=u.createElement("img"),P="srcset"in t&&!("sizes"in t),E=!!f.HTMLPictureElement&&!P;function N(a,t,s){var e,r,i,n,o,c=f.getComputedStyle(a);if(s){for(n in o={},s)o[n]=s[n];s=o}else r=a.parentNode,s={isPicture:!(!r||!p.test(r.nodeName||""))};for(e in i=function(t,e){var r,i=a.getAttribute("data-"+t);if(i||(r=c.getPropertyValue("--ls-"+t))&&(i=r.trim()),i){if("true"==i)i=!0;else if("false"==i)i=!1;else if(l.test(i))i=parseFloat(i);else if("function"==typeof m[t])i=m[t](a,i);else if(z.test(i))try{i=JSON.parse(i)}catch(t){}s[t]=i}else t in m&&"function"!=typeof m[t]&&!s[t]?s[t]=m[t]:e&&"function"==typeof m[t]&&(s[t]=m[t](a,i))},m)i(e);return t.replace(h,function(t,e){e in s||i(e,!0)}),s}function _(t,e,r){var s,n,o,i=0,a=0,c=r;if(t){if("container"===e.ratio){for(i=c.scrollWidth,a=c.scrollHeight;!(i&&a||c===u);)i=(c=c.parentNode).scrollWidth,a=c.scrollHeight;i&&a&&(e.ratio=e.traditionalRatio?a/i:i/a)}s=t,n=e,(o=[]).srcset=[],n.absUrl&&(w.setAttribute("href",s),s=w.href),s=((n.prefix||"")+s+(n.postfix||"")).replace(h,function(t,e){return d[typeof n[e]]?n[e]:t}),n.widths.forEach(function(t){var e=n.widthmap[t]||t,r=n.aspectratio||n.ratio,i=!n.aspectratio&&m.traditionalRatio,a={u:s.replace(v,e).replace(y,r?i?Math.round(t*r):Math.round(t/r):""),w:t};o.push(a),o.srcset.push(a.c=a.u+" "+t+"w")}),(t=o).isPicture=e.isPicture,P&&"IMG"==r.nodeName.toUpperCase()?r.removeAttribute(b.srcsetAttr):r.setAttribute(b.srcsetAttr,t.srcset.join(", ")),Object.defineProperty(r,"_lazyrias",{value:t,writable:!0})}}function x(t){return t.getAttribute(t.getAttribute("data-srcattr")||m.srcAttr)||t.getAttribute(b.srcsetAttr)||t.getAttribute(b.srcAttr)||t.getAttribute("data-pfsrcset")||""}!function(){var t,e={prefix:"",postfix:"",srcAttr:"data-src",absUrl:!1,modifyOptions:function(){},widthmap:{},ratio:!1,traditionalRatio:!1,aspectratio:!1};for(t in(b=g&&g.cfg).supportsType||(b.supportsType=function(t){return!t}),b.rias||(b.rias={}),"widths"in(m=b.rias)||(m.widths=[],function(t){for(var e,r=0;!e||e<3e3;)30<(r+=5)&&(r+=1),e=36*r,t.push(e)}(m.widths)),e)t in m||(m[t]=e[t])}(),addEventListener("lazybeforesizes",function(t){if(t.detail.instance==g){var e,r,i,a,s,n,o,c,u,d,f,l=t.target;if(t.detail.dataAttr&&!t.defaultPrevented&&!m.disabled&&(o=l.getAttribute(b.sizesAttr)||l.getAttribute("sizes"))&&A.test(o)){var p,y,h=x(l);if(y=N(p=l,h),m.modifyOptions.call(p,{target:p,details:y,detail:y}),g.fire(p,"lazyriasmodifyoptions",y),e=y,u=v.test(e.prefix)||v.test(e.postfix),e.isPicture&&(r=l.parentNode))for(a=0,s=(i=r.getElementsByTagName("source")).length;a<s;a++)(u||v.test(n=x(i[a])))&&(_(n,N(i[a],n,e),i[a]),d=!0);u||v.test(h)?(_(h,e,l),d=!0):d&&((f=[]).srcset=[],f.isPicture=!0,Object.defineProperty(l,"_lazyrias",{value:f,writable:!0})),d&&(E?l.removeAttribute(b.srcAttr):"auto"!=o&&(c={width:parseInt(o,10)},M({target:l,detail:c})))}}},!0);var a,M=(a=function(t){var e,r;t.detail.instance==g&&(r=t.target,P||!(f.respimage||f.picturefill||i.pf)?("_lazyrias"in r||t.detail.dataAttr&&O(r,!0))&&(e=s(r,t.detail.width))&&e.u&&r._lazyrias.cur!=e.u&&(r._lazyrias.cur=e.u,e.cached=!0,g.rAF(function(){r.setAttribute(b.srcAttr,e.u),r.setAttribute("src",e.u)})):u.removeEventListener("lazybeforesizes",a))},E?a=function(){}:addEventListener("lazybeforesizes",a),a);function L(t,e){return t.w-e.w}function O(t,e){var r;return!t._lazyrias&&g.pWS&&(r=g.pWS(t.getAttribute(b.srcsetAttr||""))).length&&(Object.defineProperty(t,"_lazyrias",{value:r,writable:!0}),e&&t.parentNode&&(r.isPicture="PICTURE"==t.parentNode.nodeName.toUpperCase())),t._lazyrias}function s(t,e){var r,i,a,s,n,o,c,u,d=t._lazyrias;if(d.isPicture&&f.matchMedia)for(i=0,a=(r=t.parentNode.getElementsByTagName("source")).length;i<a;i++)if(O(r[i])&&!r[i].getAttribute("type")&&(!(s=r[i].getAttribute("media"))||(matchMedia(s)||{}).matches)){d=r[i]._lazyrias;break}return(!d.w||d.w<e)&&(d.w=e,d.d=(o=t,c=f.devicePixelRatio||1,u=g.getX&&g.getX(o),Math.min(u||c,2.4,c)),n=function(t){for(var e,r,i=t.length,a=t[i-1],s=0;s<i;s++)if((a=t[s]).d=a.w/t.w,a.d>=t.d){!a.cached&&(e=t[s-1])&&e.d>t.d-.13*Math.pow(t.d,2.2)&&(r=Math.pow(e.d-.6,1.6),e.cached&&(e.d+=.15*r),e.d+(a.d-t.d)*r>t.d&&(a=e));break}return a}(d.sort(L))),n}});