(function () {
  var terms_url = "/2716001/policies/1042710.html";
  var privacy_url = "/2716001/policies/1042712.html";

  var markup = `
  <div class="section__content">
    <div class="content-box">
      <div class="content-box__row">
        <div class="checkbox-wrapper">
          <div class="checkbox__input">
            <input type="hidden" name="checkout[attributes][trs_third_party_opt_out]" value="0">
            <input class="input-checkbox" type="checkbox" value="1" name="checkout[attributes][trs_third_party_opt_out]" id="trs_third_party_opt_out">
          </div>
          <label class="checkbox__label" for="trs_third_party_opt_out">I'm happy to receive the occasional brochure or catalogue from similar companies from time to time. </label>
        </div>
      </div>
      <div class="content-box__row">
        <div class="checkbox-wrapper">
          <div class="checkbox__input">
            <input type="hidden" name="checkout[attributes][Gift Receipt]" value="No">
            <input class="input-checkbox" type="checkbox" value="Yes" name="checkout[attributes][Gift Receipt]" id="trs_gift_receipt">
          </div>
          <label class="checkbox__label" for="trs_gift_receipt">Check this box to receive a gift receipt</label>
        </div>
      </div>
    </div>
  </div>
  `;

  // Remember me doesn't always appear, so fallback to billing address
  var hookPoint = document.getElementsByClassName("section--remember-me");

  if (!hookPoint.length) {
    hookPoint = document.getElementsByClassName("section--billing-address");
  }

  hookPoint = hookPoint[0];

  if (hookPoint) {
    var newContent = document.createElement("div");
    newContent.className = "section";
    newContent.innerHTML = markup;
    hookPoint.parentNode.insertBefore(newContent, hookPoint.nextSibling);

    // Custom attributes
    hookPoint.append(document.getElementById("js-checkout-attributes"));
  }

  if (Shopify.Checkout.step == "payment_method") {
    var termsMarkup = `
  <div class="section" style="padding-top: 0em; margin-top: 1.5em;">
    <div class="section__content" style="border: 1px solid #d9d9d9; border-radius: 4px;">
      <div class="content-box__row">
        <div class="checkbox-wrapper" id="trs-terms-wrapper">
          <div class="checkbox__input"></div>
          <label class="checkbox__label" for="trs_terms">
            By clicking pay now you accept our <a aria-haspopup="dialog" data-modal="policy-1042710" data-close-text="Close" href="${terms_url}">Terms and Conditions</a>
          </label>
        </div>
      </div>
    </div>
  </div>
  `;

    $(".step__footer").after(termsMarkup);
  }

  // Add Klarna terms to payment options
  $(
    "#payment-gateway-subfields-18590826568 div.blank-slate, #payment-gateway-subfields-18464178248 div.blank-slate"
  ).prepend(
    '<p style="margin-bottom:1rem;">Please note there is a 24 hour processing period for all orders placed with Klarna</p>'
  );
})();
